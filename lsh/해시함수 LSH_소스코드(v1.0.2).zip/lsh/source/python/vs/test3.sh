#!
echo "Testing for Python3"
python3 lshvs.py
