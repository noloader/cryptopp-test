#ifndef _LEA_VS_H_
#define _LEA_VS_H_

int lea_mmt_ecb_test(void);
int lea_mmt_cbc_test(void);
int lea_mmt_ctr_test(void);
int lea_mmt_ofb_test(void);
int lea_mmt_cfb_test(void);

int lea_cmac_g_test(void);
int lea_ccm_ge_test(void);
int lea_gcm_ae_test(void);


#endif
