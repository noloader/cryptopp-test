#-*- coding: utf-8 -*-

from distutils.core import setup

setup(
    name = 'lea',
    version = '1.2.0',
    packages = ['LEA'],
    author = 'NSR',
    description = 'LEA Crypto',
)